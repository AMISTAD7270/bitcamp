'''번호판 후보영역 검색'''

from plate_preprocess import *               # 전처리 및 후보 영역 검출 함수

car_no = int(input("자동차 영상 번호 (0~15): "))
image, morph = preprocessing(car_no)                       # 전처리 - 이진화(소벨&열림 연산)
if image is None: Exception("영상 읽기 에러")

candidates = find_candidates(morph)                        # 번호판 후보 영역 검색
for candidate in candidates:                               # 후보 영역 표시
    pts = np.int32(cv2.boxPoints(candidate))
    # cv2.boxPoints : 회전 사각형의 4개 꼭지점 좌표를 가져온다
    # 좌표를 그리기 위해 모든 원소들을 정수형 행렬로 변경하여 pts에 저장
    cv2.polylines(image, [pts], True, (0, 225, 255), 2)    # 다중 좌표 잇기
    # cv2.polylines : pts 원소(좌표)를 잇는 직선을 그린다.
    print(candidate)
    # 후보 영역의 시작 좌표, 크기, 회전 각도를 출력(1번 사진으로 출력해보기)

if not candidates:                                         # 리스트 원소가 없으면
    print("번호판 후보 영역 미검출")
cv2.imshow("image", image)
cv2.waitKey(0)