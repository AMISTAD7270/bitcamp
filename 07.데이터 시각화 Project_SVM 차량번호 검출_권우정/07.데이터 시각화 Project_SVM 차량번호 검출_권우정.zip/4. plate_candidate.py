import numpy as np, cv2

'''번호판 후보영역 영상 생성'''

'''후보영역 개선 함수-컬러 활용'''
def color_candidate_img(image, center):
    h, w = image.shape[:2]
    fill = np.zeros((h + 2, w + 2), np.uint8)           # 채움 행렬
    dif1, dif2 = (25, 25, 25), (25, 25, 25)             # 채움 색상 범위
    # dif1 : 색상 범위 중 하위값 / dif2 : 상위값
    flags = 0xff00 + 4 + cv2.FLOODFILL_FIXED_RANGE      # 채움 방향 및 방법
    # cv.FloodFill() : 내부 채우기
    # cv2.FLOODFILL_FIXED_RANGE : 시드 좌표(x, y)와 4방향 이웃 좌표의 화소값 차분이 범위 이내인지 확인해서 채움.
    flags += cv2.FLOODFILL_MASK_ONLY                    # 입력 연상은 변경하지 않고, 결과 영상만 채움

    # 후보 영역을 유사 컬러로 채우기
    pts = np.random.randint(-15, 15, (20, 2))           # 임의 좌표 20개 생성
    # 20행 2열로 pts 행렬의 원소를 -15~15 범위의 값으로 랜덤하게 생성
    # print(pts)
    pts = pts + center                                  # 임의 좌표들을 번호판 후보 영상의 중심 좌표만큼 평행이동
    for x, y in pts:                                    # 임의 좌표 순회
        if 0 <= x < w and 0 <= y < h:                   # 후보 영역 내부이면(랜덤 평행이동 좌표가 입력 영상 범위 안인지 검사)
            _, _, fill, _ = cv2.floodFill(image, fill, (x, y), 255, dif1, dif2, flags)  # 채움 누적
            # 랜덤 좌표가 영상 범위이면 cv2.floodFill() 함수로 랜덤 좌표(x, y)와 비슷한 색상들을 흰색으로 채워서 fill 행렬에 저장하며,
            # 이 과정을 20개 좌표에 대해 반복 수행해서 fill 행렬에 누적한다.

    # 이진화 및 외곽영역 추출후 회전 사각형 검출
    return cv2.threshold(fill, 120, 255, cv2.THRESH_BINARY)[1]
    # 비슷한 색상 영역이 누적된 fill 행렬을 이진화하여 반환.

'''후보영상 보정 함수 구현'''
def rotate_plate(image, rect):  # 검출된 번호판 후보 영역에 대해 회전을 보정하는 함수
    center, (w, h), angle = rect       # 중심 좌표, 크기, 회전 각도
    if w < h:                         # 세로가 긴 영역이면
        w, h = h, w                    # 가로와 세로 맞바꿈
        angle += 90                    # 회전 각도 조정

    size = image.shape[1::-1]          # 행태와 크기는 역순
    rot_mat = cv2.getRotationMatrix2D(center, angle, 1)  # 회전 변환 행렬을 계산
    # cv2.getRotationMatrix2D(center, angle, scale) : 중심점(center), 각도(angle), 비율(scale)
    # 결과값을 2x3의 Affine 변환 행렬로 반환함
    rot_img = cv2.warpAffine(image, rot_mat, size, cv2.INTER_CUBIC)  # 회전 변환
    # 변환 행렬(rot_mat)을 cv2.warpAffine() 함수에 적용하면 전체 원본 영상(image)이 회전됨 / M : 2x3 변환 행렬
    # cv2.warpAffine(src, M, dsize) : 원본 이미지(src)에 M(아핀 맵 행렬)을 적용하고 출력 이미지 크기(dsize)로 변형해서 출력 이미지(dst)를 반환
    #                                 아핀 맵 행렬에 따라 회전된 이미지를 반환
    # cv2.INTER_CUBIC : 이미지를 확대하는 경우, 많이 사용하는 바이큐빅 보간법(3차회선 보간법)
    # 보간법(interpolation) : 변환 행렬을 적용할 때 대상 이미지의 일부 픽셀에는 원본 이미지의 선행도가 없을 수 있는데, 이러한 픽셀에는
    #         정의된 값이 없으므로, 이 픽셀의 로컬 인접을 사용하여 값을 계산해 이러한 차이를 채우는 것.
    crop_img = cv2.getRectSubPix(rot_img, (w, h), center)  # 후보영역 가져오기
    # 이미지 크롭하기(입력 이미지, 출력 이미지의 크기, 직사각형의 중심)
    # 회전 영상(rot_img)에 cv2.getRectSubPix() 함수로 후보 영역 중심(center)에서 후보 영역의 크기(w, h)만큼을 가져오면 회전 보정된
    # 번호판 후보 영상(crop_img)이 된다.
    crop_img = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)  # 명암도 영상
    return cv2.resize(crop_img, (144, 28))                 # 크기변경 후 반환
    # SVM 학습에 사용했던 학습 데이터셋(번호판 영상)의 크기와 같도록 가로 144, 세로 28의 크기로 정규화하여 반환.