import numpy as np, cv2
from pprint import *

'''번호판 후보 영역 검색'''

'''전처리 함수 구현 : 명암도 영상 변환, 블러링 및 소벨 에지 검출/이진화 및 모폴로지 열림 연산 수행'''
def preprocessing(car_no):
    image = cv2.imread("images/car/test_car/%02d.jpg" % car_no, cv2.IMREAD_COLOR)
    if image is None: return None, None

    kernel = np.ones((5, 17), np.uint8)  # 닫힘 연산 마스크(커널)
    # 번호판 영역은 가로로 긴 모양을 하나의 영역으로 구성해야 함. -> 수직 방향 에지에 모폴로지 닫힘 연산을 가로로 긴 커널(5행 17열)을
    # 구성하여 수행하면 가로로 긴 영역이 합쳐짐. -> 닫힘 연산을 3번 수행.
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # 명암도 영상 변환 검0~255흰
    #       색상 공간 변환 함수 , BGR2GRAY = 원본 이미지 색상 공간(RGB 색상 채널) 2 결과 이미지 색상 공간
    # print("gray")
    # pprint(gray)  # pprint로 뽑아낸 값 : 각 픽셀의 RGB 값들을 행렬로 출력
    gray1 = cv2.blur(gray, (5, 5))  # 블러링
    #      단순 흐림 효과 함수, 커널 크기?
    # print("gray1")
    # pprint(gray1)
    gray2 = cv2.Sobel(gray1, cv2.CV_8U, 1, 0, 3)  # 수직(소벨) 에지 검출
    # 소벨 함수 : 미분 값을 구할 때 사용하는 연산자. 인접한 픽셀들의 차이로 기울기의 크기를 구함.
    # CV_8U : 범위 0~255 # 1 : X 방향 미분 차수 # 0 : Y 방향 미분 차수 # 3 : 커널 크기(소벨 마스크의 크기)
    # print("gray2")
    # pprint(gray2)
    th_img = cv2.threshold(gray2, 120, 255, cv2.THRESH_BINARY)[1]  # 이진화 수행
    # _, th_img = cv2.threshold(gray2, 120, 255, cv2.THRESH_BINARY)
    # 윗줄이랑 밑줄이랑 똑같은 뜻. 위는 1열부터 가져오겠다/밑은 처음껀 빼고 출력하겠다=>결국 똑같음
    # 이진화 : 어느 지점을 기준으로 값이 높거나 낮은 픽셀의 값을 대상으로 특정 연산을 수행할 때 사용.
    #         일반적으로 값이 높거나 낮은 픽셀을 검은색 or 흰색 값으로 변경.
    #         기준값에 따라 이분법적으로 구분해 픽셀을 차 또는 거짓으로 나누는 연산.
    # cv2.threshold : 이진화함수 / 120 : 임계값 / 255 : 최대값
    # cv2.THRESH_BINARY : dst = (src > thresh) ? maxval : 0 (임곗값을 초과할 경우 maxval-255-, 아닐 경우 0)
    # print("th_img")
    # pprint(th_img)
    morph = cv2.morphologyEx(th_img, cv2.MORPH_CLOSE, kernel, iterations=3)
    # cv2.morphologyEx(원본 배열, 연산 방법, 구조 요소, 고정점, 반복 횟수, 테두리 외삽법, 테두리 색상)
    # iterations : 연산 반복 횟수
    # cv2.MORPH_CLOSE : 닫힘 연산(팽창 연산으로 인해 어두운 영역이 줄어들고 밝은 영역이 늘어남)
    # print("morph")
    # pprint(morph)

    cv2.imshow("gray", gray);
    cv2.imshow("gray1 blur", gray1)
    cv2.imshow("gray2 sobel", gray2)
    cv2.imshow("th_img", th_img); cv2.imshow("morph", morph)  # 결과 표시
    return image, morph

'''번호판 후보영역 판정 함수'''
def verify_aspect_size(size):
    w, h = size
    if h == 0 or w == 0: return False

    aspect = h / w if h > w else w / h  # 종횡비 계산 / 세로가 길면 역수 취함
    chk1 = 3000 < (h * w) < 12000       # 번호판 넓이 조건 3000 12000
    chk2 = 2.0 < aspect < 6.5          # 번호판 종횡비 조건 2.0 6.5
    return (chk1 and chk2)

# 검출 영역의 넒이가 3000~12000 범위, 종횡비가 2.0~6.5 범위면 번호판 후보 영역으로 판단하는 함수.

def find_candidates(image):
    results = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    #        윤곽선(객체 외곽선) 검출      , 외곽 윤곽선만 검출  , 윤곽점들 단순화. 수평•수직 및 대각선 요소를 압축하고 끝점만 남겨둠.
    contours = results[0] if int(cv2.__version__[0]) >= 4 else results[1]
    #                                버전이 4일때 (a,b)       버전 4미만 (c,a,b)
    # 버전이 4 이상일때는 원하는 값이 0열부터 있음/4 미만일때는 원하는 값이 1열부터 있음. 그래서 [1] 써주는거..
    rects = [cv2.minAreaRect(c) for c in contours]  # 회전 사각형 반환
    # cv2.minAreaRect : 최소 면적 사각형 함수(윤곽선의 경계면을 둘러싸는 최소 크기의 사각형 계산)
    #                   검출된 외곽선의 최소 영역을 회전 사각형(중심좌표, 크기, 각도)으로 반환.
    # 검출된 외곽선(contours)을 모두 조회하며 외각 영역 회전 사각형을 리스트로 만듦.
    # rects = 검출된 회전 사각형!!!
    candidates = [(tuple(map(int, center)), tuple(map(int, size)), angle)  # 정수형 반환
                  for center, size, angle in rects if verify_aspect_size(size)]
    # 검출 영역이 후보 영역인 회전 사각형만 모아서 후보 영역 리스트(candidates)를 만듦.

    return candidates
#
# def draw_rotatedRect(image, rot_rect, color, thickness=2 , mode=False):
#     box = cv2.boxPoints(rot_rect)
#     pts = [pt for pt in np.int32(box)]           # box 원소의 자료형을 정수형 튜플로 변환
#     cv2.polylines(image, [np.array(pts)], True, color, thickness)      # pts는 numpy 배열
#
#     if mode:                                 # true면 회전 사각형 중심점 출력
#         center , _, _ = rot_rect
#         cv2.circle(image, center, 2, (255, 0, 0), 2)
#         cv2.imshow("rotated_image", image)
#
